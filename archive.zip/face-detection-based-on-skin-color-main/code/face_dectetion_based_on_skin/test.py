import numpy as np

a = (1, 2, 3)
print(list(a))